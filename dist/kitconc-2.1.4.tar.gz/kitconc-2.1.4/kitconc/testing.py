from kitconc.kit_corpus import Corpora, Corpus
